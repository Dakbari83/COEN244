#include "Employee.h"
#include <iostream>
#include <string>
using namespace std;

Employee::Employee():first(""), last(""), salary(0) {} // Default constructor
Employee::Employee(string f, string l, int s):first(f), last(l), salary((s<1)? 0:s) {} // Parameter-based constructor
Employee::Employee(const Employee& e):first(e.first), last(e.last), salary(e.salary) {} // Copy constructor

Employee::~Employee(){ // Destructor
    cout << "the destructor was called." << endl;

}


// Getter functions

string Employee::getFirst() const{
    return first;
}

string Employee::getLast() const{
    return last;
}

int Employee::getSalary() const{
    return salary;
}

// Setter functions

void Employee::setFirst(string f){
    first = f;
}

void Employee::setLast(string l){
    last = l;
}

void Employee::setSalary(int s){
    salary = (s<1)? 0:s;
}



void Employee::display() const{
    cout << "full name: " << first << " " << last << "\tsalary: " << salary << endl;
}

void Employee::displayYearlySalary() const{
    cout << "Yearly salary: " << salary * 12 << endl;
}

void Employee::giveRaise(double percent){
    salary = salary * (1 + (percent / 100.0));
}

