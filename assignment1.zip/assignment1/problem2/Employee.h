#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <iostream>
#include <string>
using namespace std;

class Employee{

    private:
        string first;
        string last;
        int salary;

    public:
        Employee(); // Default constructor
        Employee(string, string, int); // Parameter-based constructor
        Employee(const Employee&); // Copy constructor

        ~Employee(); // destructor


        // Getters

        string getFirst() const;
        string getLast() const;
        int getSalary() const;

        // Setters

        void setFirst(string);
        void setLast(string);
        void setSalary(int);

        void display() const; // function to display an employee's info
        void displayYearlySalary() const;

        void giveRaise(double); // function to give raise to an employee by passing the raise percentage


        friend int compareSalary(const void* first, const void* second); // friended to access private data members by the compare function


};

#endif