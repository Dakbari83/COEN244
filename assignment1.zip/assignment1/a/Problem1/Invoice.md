//Daniel Akbari - ID#: 40298757

//Sepehr Ghasemzadeh Moghaddam - ID#: 40268909 

//Assignment 1 - COEN 244

//“We certify that this submission is the original work of members of the group and meets the Faculty's Expectations of Originality”

    #include <iostream>
    #include <string>
    using namespace std;

    
    class Invoice{

Inside of private section of the class we mention the property and members of that class:

    private:
        string partNumber;
        string partDescription;
        int quantity;
        int price;
    
Inside of the public section, we put Constructors, Get and Set functions: 

    public:
Default Constructor: initialize the members to default values

        Invoice(); // Default constructor
        Invoice::Invoice():partNumber("0"),partDescription(""), quantity(0), price(0) {} // Default Constructor

Parameter-based constructor: initialize each parameter to a specific value, checks if quantity or price is non-positive

        Invoice(string, string, int, int); // Parameter-based constructor
        Invoice::Invoice(string number, string description, int q, int p):partNumber(number), partDescription(description), quantity((q<1)? 0:q), price((p<1)? 0:p) {}  

Copy constructor: Copy the members' value of an already created object to the new object created

        Invoice(const Invoice&); // Copy constructor
        Invoice::Invoice(const Invoice& i):partNumber(i.partNumber), partDescription(i.partDescription), quantity(i.quantity), price(i.price) {} // Copy constructor

Destructor: to clean the memory and prevent any heavy duty

        ~Invoice(); // Destructor
        Invoice::~Invoice(){}

As we put the members of the class inside private, it can only be accessed by the functions inside the class, 
so we make get function for each member to cout and show the values and data for each of them.

    // Get functions
    string getPartNumber() const;
    string Invoice::getPartNumber() const{
    return partNumber;
    }

    string getPartDescription() const;
    string Invoice::getPartDescription() const{
    return partDescription;
    }

    int getQuantity() const;
    int Invoice::getQuantity() const{
    return quantity;
    }

    int getPrice() const;
    int Invoice::getPrice() const{
    return price;
    }

Same as get function, as the members of class are private, we can not assign any input value by just using assign operation
(like int a = 10), we make set functions that are inside of the class to be able to assign a value for members

    // Set functions
    void setPartNumber(string);
    void Invoice::setPartNumber(string n){
    partNumber = n;
    }
    void setPartDescription(string);
    void Invoice::setPartDescription(string d){
    partDescription = d;
    }

    void setQuantity(int);
    void Invoice::setQuantity(int q){
    quantity = (q<1)? 0:q;
    }
    void setPrice(int);
    void Invoice::setPrice(int p){
    price = (p<1)? 0 : p;
    }

Function to calculate the total obtained money by sold stuff

    int getInvoiceAmount() const;
    int Invoice::getInvoiceAmount() const{
    return quantity * price;
    }

Function to make a copy after the original object already created

    Invoice clone() const;
    Invoice Invoice::clone() const{
    Invoice clone;
    clone.partNumber = partNumber;
    clone.partDescription = partDescription;
    clone.price = price;
    clone.quantity = quantity;
    
        return clone;
    }

overloaded version of clone()

    Invoice clone(const Invoice&);
    Invoice Invoice::clone(const Invoice& i){
    Invoice clone;
    clone.partNumber = i.partNumber;
    clone.partDescription = i.partDescription;
    clone.price = i.price;
    clone.quantity = i.quantity;
    
        return clone;
    }

Functions for displaying

    void display() const;
    void Invoice::display() const{
    cout << "part number: " << partNumber << "\tpart description: " << partDescription << "\tprice per item: " << price << "\tquantity: " << quantity << endl;
    }

In Driver + Testing Function

    static int pass=0, fail=0;

Test Function for Default Constructor:

    bool testDefaultConstructor(){
        Invoice i;
        if((i.getPartNumber() == "0") && (i.getPartDescription() == "") && (i.getPrice() == 0 ) && (i.getQuantity() == 0)) {
        pass++;
        return true;
        }
    
        else{
            fail++;
            return false;
        }
    }

Test Function for Parameter Constructor:

    bool testParameterConstructor(){
        Invoice i("123", "desk", -2, 0), j("5", "chair", 50, 2);
        if((i.getPartNumber() == "123") && (i.getPartDescription() == "desk") && (i.getPrice() == 0 ) && (i.getQuantity() == 0) && (j.getPartNumber() == "5") && (j.getPartDescription() == "chair") && (j.getPrice() == 2) && (j.getQuantity() == 50)) {
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Copy Constructor:

    bool testCopyConstructor(){
        Invoice i("23", "mouse", 35, 8);
        Invoice j(i);
        if((j.getPartNumber() == "23") && (j.getPartDescription() == "mouse") && (j.getPrice() == 8 ) && (j.getQuantity() == 35)){
        pass ++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Get Functions inside class:

    bool testGetFunctions(){
        Invoice i("67", "book", 150, 12);
        if((i.getPartNumber() == "67") && (i.getPartDescription() == "book") && (i.getPrice() == 12 ) && (i.getQuantity() == 150)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Set Functions inside class:

    bool testSetFunctions(){
        Invoice i, j;
        i.setPartNumber("762");
        i.setPartDescription("bottle");
        i.setPrice(32);
        i.setQuantity(17);
    
        j.setPartNumber("0");
        j.setPartDescription("no");
        j.setPrice(-5);
        j.setQuantity(-12);
    
        if((i.getPartNumber() == "762") && (i.getPartDescription() == "bottle") && (i.getPrice() == 32 ) && (i.getQuantity() == 17) && (j.getPartNumber() == "0") && (j.getPartDescription() == "no") && (j.getPrice() == 0) && (j.getQuantity() == 0)){
            pass++;
            return true;
        }
        else{
            fail++;
            return false;
        }
    }

Test Function for Get Invoice Function inside class:

    bool testGetInvoiceAmount(){
        Invoice i("789", "ipad", 15, 3);
        if(i.getInvoiceAmount() == 45){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Clone Function inside class:

    bool testCloneFunction1(){
        Invoice i("890", "mac", 145, 7999);
        Invoice j = i.clone();
        if((j.getPartNumber() == "890") && (j.getPartDescription() == "mac") && (j.getPrice() == 7999 ) && (j.getQuantity() == 145)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for overloaded version of  Clone Function inside class:

    bool testCloneFunction2(){
        Invoice i("890", "mac", 145, 7999);
        Invoice j;
        j = j.clone(i);
        if((j.getPartNumber() == "890") && (j.getPartDescription() == "mac") && (j.getPrice() == 7999 ) && (j.getQuantity() == 145)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }
  
    



