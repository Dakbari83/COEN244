//Daniel Akbari - ID#: 40298757

//Sepehr Ghasemzadeh Moghaddam - ID#: 40268909

//Assignment 1 - COEN 244

//“We certify that this submission is the original work of members of the group and meets the Faculty's Expectations of Originality”

    #include <iostream>
    #include <string>
    using namespace std;
    
    class Employee{

Inside of private section of the class we mention the property and members of that class:

    private:
        string first;
        string last;
        int salary;

Inside of the public section, we put Constructors, Get and Set functions:

    public:
Default Constructor: initialize the members to default values

    Employee(); // Default constructor
    Employee::Employee():first(""), last(""), salary(0) {}  

Parameter-based constructor: initialize each parameter to a specific value

    Employee(string, string, int); // Parameter-based constructor
    Employee::Employee(string f, string l, int s):first(f), last(l), salary((s<1)? 0:s) {}

Copy constructor: Copy the members' value of an already created object to the new object created

    Employee(const Employee&);
    Employee::Employee(const Employee& e):first(e.first), last(e.last), salary(e.salary) {}


Destructor: to clean the memory and prevent any heavy duty

    ~Employee(); // destructor
    Employee::~Employee(){}

As we put the members of the class inside private, it can only be accessed by the functions inside the class,
so we make get function for each member to cout and show the values and data for each of them.

    //Get functions
    string getFirst() const;
    string Employee::getFirst() const{
    return first;
    }

    string getLast() const;
    string Employee::getLast() const{
    return last;
    }

    int getSalary() const;
    int Employee::getSalary() const{
    return salary;
    }

Same as get function, as the members of class are private, we can not assign any input value by just using assign operation
(like int a = 10), we make set functions that are inside of the class to be able to assign a value for members

    //Set Functions
    void setFirst(string);
    void Employee::setFirst(string f){
    first = f;
    }

    void setLast(string);
    void Employee::setLast(string l){
    last = l;
    }

    void setSalary(int);
    void Employee::setSalary(int s){
    salary = (s<1)? 0:s;
    }

Functions for displaying info

    void display() const;
    void Employee::display() const{
    cout << "full name: " << first << " " << last << "\tsalary: " << salary << endl;
    }

    void displayYearlySalary() const;
    void Employee::displayYearlySalary() const{
    cout << "Yearly salary: " << salary * 12 << endl;
    }

Function for giving raise to an employee by passing the raise percentage

    void giveRaise(double); 
    void Employee::giveRaise(double percent){
    salary = salary * (1 + (percent / 100.0));
    }

Friended to access private data members by the compare function

    friend int compareSalary(const void* first, const void* second); // friended to access private data members by the compare function
    };

    int compareSalary(const void* first, const void* second){
        const Employee* employee1 = static_cast <const Employee*> (first);
        const Employee* employee2 = static_cast <const Employee*> (second);
        
            int s = static_cast <int> (employee1->salary - employee2->salary);
        
            return s;
    }
    
    static bool test;
    
    double testMaxEmployeeSalary(){
        Employee e("josh", "bouchard", 105000.99);
        Employee arrayEmployee[] = { Employee("dan", "tremblay", 54321), Employee(), e, Employee(e), Employee("sep", "man", 96743.25), Employee("", "", 150500.5), Employee("", "", 86034), Employee("", "", 143753), Employee("", "", 120432), Employee("", "", 189000), Employee("", "", 145234.24), Employee("", "", 178922)};
        
            size_t arraySize = sizeof(arrayEmployee) / sizeof (arrayEmployee[0]); 
        
            qsort (arrayEmployee, arraySize, sizeof(arrayEmployee[0]), compareSalary); 
    
for (Employee item : arrayEmployee)
item.display();
    
            if((arrayEmployee[11].getSalary())==189000){
                test = true;
                pass++;
            }
            else {
                test = false;
                fail++;
            }
                
            return (arrayEmployee[11].getSalary());
        }

In Driver + Testing Function

    static int pass=0, fail=0;

Test Function for Default Constructor:

    bool testDefaultConstructor(){
        Employee e;
        if((e.getFirst() == "" ) && (e.getLast() == "") && (e.getSalary() == 0)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    
    }

Test Function for Copy Constructor:

    bool testCopyConstructor(){
        Employee e("danny", "chambly", 54321);
        Employee copied(e);
        if((copied.getFirst() == "danny" ) && (copied.getLast() == "chambly") && (copied.getSalary() == 54321)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Parameter Constructor:

    bool testParameterConstructor(){
        Employee e("dan", "anne", 76543), i("mac", "book", -5);
        if((e.getFirst() == "dan" ) && (e.getLast() == "anne") && (e.getSalary() == 76543) && (i.getFirst() == "mac") && (i.getLast() == "book") && (i.getSalary() == 0)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Get Functions inside class:

    bool testGetFunctions(){
        Employee e("brian", "maccy", 9876);
        if((e.getFirst() == "brian") && (e.getLast() == "maccy") && (e.getSalary() == 9876)){
        pass++;
        return true;
        }
        else{
        fail++;
        return false;
        }
    }

Test Function for Set Functions inside class:

    bool testSetFunctions(){
    Employee i,j;
    i.setFirst("sep");
    i.setLast("akb");
    i.setSalary(85643);
    
        j.setFirst("dannn");
        j.setLast("woah");
        j.setSalary(12345);
    
        if((i.getFirst() == "sep") && (i.getLast() == "akb") && (i.getSalary() == 85643) && (j.getFirst() == "dannn") && (j.getLast() == "woah") && (j.getSalary() == 12345)){
            pass++;
            return true;
        }
        else{
            fail++;
            return false;
        }
    }

Test Function for Giving Rise Functions inside class:

    bool testGiveRaise(){
    Employee i("", "", 1000),j("", "", 50000);
    i.displayYearlySalary(); // displaying their yearly salaries before the raise
    j.displayYearlySalary();
    
        i.giveRaise(10);
        j.giveRaise(25);
        i.displayYearlySalary(); // displaying their yearly salaries after the raise
        j.displayYearlySalary();
    
        if((i.getSalary() == 1100) && (j.getSalary() == 62500)){
            pass++;
            return true;
        }
    
        else{
            fail++;
            return false;
        }
    }
