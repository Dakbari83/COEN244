#include "Invoice.h"
#include <iostream>
#include <string>
using namespace std;

Invoice::Invoice():partNumber("0"),partDescription(""), quantity(0), price(0) {} // Default Constructor
Invoice::Invoice(string number, string description, int q, int p):partNumber(number), partDescription(description), quantity((q<1)? 0:q), price((p<1)? 0:p) {} // Parameter Constructor that checks if quantity or price is non-positive
Invoice::Invoice(const Invoice& i):partNumber(i.partNumber), partDescription(i.partDescription), quantity(i.quantity), price(i.price) {} // Copy constructor


Invoice::~Invoice(){ // Destructor
    cout << "the destructor was called." << endl;
}

// Getter functions

string Invoice::getPartNumber() const{
    return partNumber;
}

string Invoice::getPartDescription() const{
    return partDescription;
}

int Invoice::getPrice() const{
    return price;
}

int Invoice::getQuantity() const{
    return quantity;
}

// Setter functions

void Invoice::setPartNumber(string n){
    partNumber = n;
}

void Invoice::setPartDescription(string d){
    partDescription = d;
}

void Invoice::setPrice(int p){
    price = (p<1)? 0 : p;
}

void Invoice::setQuantity(int q){
    quantity = (q<1)? 0:q;
}

int Invoice::getInvoiceAmount() const{
    return quantity * price;
}

Invoice Invoice::clone(){
    Invoice clone;
    clone.partNumber = partNumber;
    clone.partDescription = partDescription;
    clone.price = price;
    clone.quantity = quantity;

    return clone;
}

Invoice Invoice::clone(const Invoice& i){
    Invoice clone;
    clone.partNumber = i.partNumber;
    clone.partDescription = i.partDescription;
    clone.price = i.price;
    clone.quantity = i.quantity;

    return clone;
}

void Invoice::display() const{
    cout << "part number: " << partNumber << "\tpart description: " << partDescription << "\tprice per item: " << price << "\tquantity: " << quantity << endl;
}