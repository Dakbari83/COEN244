#ifndef INVOICE_H
#define INVOICE_H

#include <iostream>
#include <string>
using namespace std;


class Invoice{
    private:
        string partNumber;
        string partDescription;
        int quantity;
        int price;
    
    public:
        Invoice(); // Default constructor
        Invoice(string, string, int, int); // Parameter-based constructor
        Invoice(const Invoice&); // Copy constructor

        ~Invoice(); // Destructor


        // Get functions
        string getPartNumber() const;
        string getPartDescription() const;
        int getQuantity() const;
        int getPrice() const;

        // Set functions
        void setPartNumber(string);
        void setPartDescription(string);
        void setQuantity(int);
        void setPrice(int);

        int getInvoiceAmount() const;
        Invoice clone();
        Invoice clone(const Invoice&);

        void display() const;


};


#endif